const express = require('express');
const router = express.Router();
const dashboardController = require('../controllers/dashboardController');
const auth = require('../middleware/auth');

// Note the commas: route, middleware, controller
router.get('/stats', auth, dashboardController.getAnalytics);

module.exports = router;