const Task = require('../models/Task');
const { fn, col } = require('sequelize');

exports.getAnalytics = async (req, res) => {
  try {
    const userId = req.user.id;
    const totalTasks = await Task.count({ where: { userId } });
    const completedTasks = await Task.count({ where: { userId, status: 'Completed' } });
    const completionRate = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;

    const priorityBreakdown = await Task.findAll({
      where: { userId },
      attributes: ['priority', [fn('COUNT', col('id')), 'count']],
      group: ['priority']
    });

    res.json({
      summary: { totalTasks, completedTasks, completionRate: `${completionRate.toFixed(2)}%` },
      priorityBreakdown
    });
  } catch (error) {
    res.status(500).json({ error: error.message });
  }
};