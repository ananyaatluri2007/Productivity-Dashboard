const { DataTypes } = require('sequelize');
const sequelize = require('./index');

const Task = sequelize.define('Task', {
  title: { type: DataTypes.STRING, allowNull: false },
  description: { type: DataTypes.TEXT },
  priority: { type: DataTypes.ENUM('Low', 'Medium', 'High'), defaultValue: 'Medium' },
  status: { type: DataTypes.ENUM('Pending', 'In Progress', 'Completed'), defaultValue: 'Pending' },
  deadline: { type: DataTypes.DATE },
  userId: { type: DataTypes.INTEGER, allowNull: false }
}, {
  hooks: {
    afterFind: (tasks) => {
      const checkOverdue = (t) => {
        if (t.deadline && new Date(t.deadline) < new Date() && t.status !== 'Completed') {
          t.setDataValue('isOverdue', true);
        } else {
          t.setDataValue('isOverdue', false);
        }
      };
      Array.isArray(tasks) ? tasks.forEach(checkOverdue) : (tasks && checkOverdue(tasks));
    }
  }
});

module.exports = Task;