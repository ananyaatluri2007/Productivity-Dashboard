require('dotenv').config();
const sequelize = require('./src/models/index');
const Task = require('./src/models/Task');
const User = require('./src/models/User');
const bcrypt = require('bcryptjs');

const seedDatabase = async () => {
  try {
    // Sync database - { force: true } will wipe existing data to start fresh
    await sequelize.sync({ force: true });
    console.log('🔄 Database cleared and synced.');

    // 1. Create a Test User
    const hashedPassword = await bcrypt.hash('password123', 10);
    const user = await User.create({
      username: 'test_dev',
      email: 'test@example.com',
      password: hashedPassword
    });
    console.log('👤 Test user created.');

    // 2. Create Dummy Tasks (Mixed Statuses and Priorities)
    const dummyTasks = [
      { 
        title: 'Complete Project Documentation', 
        priority: 'High', 
        status: 'Completed', 
        deadline: '2026-01-10', 
        userId: user.id 
      },
      { 
        title: 'Fix Authentication Bug', 
        priority: 'High', 
        status: 'Pending', 
        deadline: '2026-01-01', // This will show as OVERDUE
        userId: user.id 
      },
      { 
        title: 'Review Peer Code', 
        priority: 'Medium', 
        status: 'In Progress', 
        deadline: '2026-02-01', 
        userId: user.id 
      },
      { 
        title: 'Update UI Assets', 
        priority: 'Low', 
        status: 'Pending', 
        deadline: '2026-02-15', 
        userId: user.id 
      },
      { 
        title: 'Submit Final Backend', 
        priority: 'High', 
        status: 'Pending', 
        deadline: '2026-01-20', 
        userId: user.id 
      }
    ];

    await Task.bulkCreate(dummyTasks);
    console.log('✅ 5 Dummy tasks created successfully!');
    
    console.log('\n--- SEEDING COMPLETE ---');
    console.log('Login Email: test@example.com');
    console.log('Login Password: password123');
    
    process.exit();
  } catch (error) {
    console.error('❌ Error seeding data:', error);
    process.exit(1);
  }
};

seedDatabase();